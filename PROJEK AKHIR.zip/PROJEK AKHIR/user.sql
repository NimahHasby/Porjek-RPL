-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Des 2020 pada 08.32
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemilik`
--

CREATE TABLE `pemilik` (
  `kode` varchar(30) NOT NULL,
  `nama_pemilik` varchar(50) NOT NULL,
  `nama_kucing` varchar(30) NOT NULL,
  `jenis_kucing` varchar(30) NOT NULL,
  `umur` varchar(30) NOT NULL,
  `noTelp` varchar(30) NOT NULL,
  `alamat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pemilik`
--

INSERT INTO `pemilik` (`kode`, `nama_pemilik`, `nama_kucing`, `jenis_kucing`, `umur`, `noTelp`, `alamat`) VALUES
('279', 'gilang', 'brian', 'anggora', '20 tahun', '0898789278', 'jalan satu'),
('799', 'sule', 'garong', 'sping', '2 tahun', '898983090', 'jalan dua satu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `petcare`
--

CREATE TABLE `petcare` (
  `username` varchar(30) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `petcare`
--

INSERT INTO `petcare` (`username`, `nama`, `password`) VALUES
('asd', 'gilang', 'ffda'),
('chozi0905', 'gilang', 'gilang0905'),
('gilang', 'ganteng', 'ganteng221'),
('sdsa', 'bambang', 'sole');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `pemilik`
--
ALTER TABLE `pemilik`
  ADD PRIMARY KEY (`kode`);

--
-- Indeks untuk tabel `petcare`
--
ALTER TABLE `petcare`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
