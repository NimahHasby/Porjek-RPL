dimohon baca telebih dahulu

cara menjalankan: buka di software eclipse dan run di software tersebut jalankan PetCare.java karena program terintegrasi dengan database makan nyalakan xampp dan import database sql

input login: jika belum mempunyai akun silahkan signup dan jika sudah memiliki akun silahkan login

input sistem: seluruh input yang diminta oleh sistem adalah data yang dibutuhkan

Output sistem: Output yang dihasilkan adalah tampilan dari pengadopsian hewan dan struk keuangan yang harus anda bayar