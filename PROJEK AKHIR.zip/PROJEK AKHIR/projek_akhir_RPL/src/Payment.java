import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Scanner;

public class Payment {
	public static Scanner masukan = new Scanner(System.in);
	public static void pembayaran(String kodeKucing, String namaUser) {
		System.out.println("############ Selamat datang di Payment ############");
		System.out.println("Pilih Jenis pembayaran");
		System.out.println("Virtual Account");
		System.out.println("Gopay");
		System.out.println("Dana");
		System.out.print("Jenis pembayaran yang anda pilih ");
		String pilihan = masukan.nextLine();
		if(pilihan.equalsIgnoreCase("Virtual Account")) {
			payBank(kodeKucing, namaUser);
		}else if(pilihan.equalsIgnoreCase("Gopay") || pilihan.equalsIgnoreCase("Dana")) {
			payVirtual(kodeKucing, namaUser);
		}else {
			System.out.println("Yang anda masukkan tidak tersedia");
			pembayaran(kodeKucing, namaUser);
		}
	}
	private static void payVirtual(String kodeKucing, String namaUser) {
		// TODO Auto-generated method stub
		String angka = "089";
		Random random = new Random();
		for(int i = 0; i < 9; i++) {
			int randomValue = random.nextInt(10);
			angka += randomValue+"";
		}
		System.out.println("************************************************************");
		System.out.println("No Pembayaran: " + angka);
		String sql = "select * from pemilik where kode = '"+kodeKucing+"'";
        Connection conn;
		try {
			conn = (Connection)config.configDB();
			Statement stm=conn.createStatement();
	        ResultSet res=stm.executeQuery(sql);
	        while(res.next()) {
	        	System.out.println("Nama Kucing : " + res.getString("nama_kucing"));
	        	System.out.println("Jenis Kucing: " + res.getString("jenis_kucing"));
	        	System.out.println("Umur Kucing : " + res.getString("umur"));
	        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Admin	 	 : Rp 1.000");
		System.out.println("Pengiriman	 : Rp 30.000");
		System.out.println("Total Pesanan: Rp 31.000");
		System.out.println("************************************************************");
		MenuUtama.menuUtama(namaUser);
		
	}
	private static void payBank(String kodeKucing, String namaUser) {
		// TODO Auto-generated method stub
		String angka = "";
		Random random = new Random();
		for(int i = 0; i < 13; i++) {
			int randomValue = random.nextInt(10);
			angka += randomValue+"";
		}
		System.out.println("************************************************************");
		System.out.println("No Virtual Account: " + angka);
		String sql = "select * from pemilik where kode = '"+kodeKucing+"'";
        Connection conn;
		try {
			conn = (Connection)config.configDB();
			Statement stm=conn.createStatement();
	        ResultSet res=stm.executeQuery(sql);
	        while(res.next()) {
	        	System.out.println("Nama Kucing : " + res.getString("nama_kucing"));
	        	System.out.println("Jenis Kucing: " + res.getString("jenis_kucing"));
	        	System.out.println("Umur Kucing : " + res.getString("umur"));
	        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Pengiriman	 : Rp 20.000");
		System.out.println("Total Pesanan: Rp 20.000");
		System.out.println("************************************************************");
		MenuUtama.menuUtama(namaUser);
		
	}
	
}
