import java.util.*;
import java.sql.*;

public class PetCare{
	public static String username, nama, password, pilihan, user, pass, cPass, noInduk;
	
	public static void main(String[] args) {
		menuAwal();
	}  

	public static void menuAwal(){
		Scanner input = new Scanner(System.in);
		System.out.println("*** PetCare Store ***");
		System.out.println("Login");
		System.out.println("SignUp");
		System.out.println("Exit");
		System.out.print("Choose your choice: ");
		pilihan = input.next();
		if(pilihan.equalsIgnoreCase("Login")){
			menuLogin();
		}else if(pilihan.equalsIgnoreCase("SignUp")){
			menuSignUp();
		}else if(pilihan.equalsIgnoreCase("Exit")){
			System.exit(0);
		}else {
			System.out.println();
			System.out.println("Tidak ada pilihan yang tepat");
			System.out.println();
			menuAwal();
		}
	}

	public static void menuLogin(){
		Scanner input = new Scanner(System.in);
		Scanner masukan = new Scanner(System.in);
		System.out.println("\n################ Welcome to Login PetCare ################");
		System.out.print("Username: ");
		user = input.nextLine();
		System.out.print("Password: ");
		pass = masukan.nextLine();
		try {
            String sql = "select * from petcare where username = '"+ user+"'";
            Connection conn=(Connection)config.configDB();
            Statement stm=conn.createStatement();
            ResultSet res=stm.executeQuery(sql);
            while(res.next()) {
            	if(res.getString("username").equals(user) && res.getString("password").equals(pass)) {
                System.out.println("\nLogin berhasil\n");
                String namaUser = res.getString("nama");
                MenuUtama.menuUtama(namaUser);
            }else {
        		System.out.println("\nanda salah memasukan data!!!");
        		System.out.println();
            	menuLogin();
        	}
            }
            
        } catch (Exception e) {
        	System.out.println("\nanda salah memasukan data!!!");
        	System.out.println();
        	menuLogin();
        	}
	}

	public static void menuSignUp(){
		Scanner input = new Scanner(System.in);
		Scanner masukan = new Scanner(System.in);
		System.out.println("\n################ Welcome to SignUp PetCare ################");
		System.out.print("Username: ");
		user = input.next();
		System.out.print("No Induk: ");
		noInduk = input.next();
		System.out.print("Nama: ");
		nama = masukan.nextLine();
		System.out.print("Password: ");
		pass = input.next();
		System.out.print("Confirm Password: ");
		cPass = input.next();
		if(noInduk.matches("[\\d]{16}") && nama.matches("[A-Za-z]*")) {
			if(!pass.equalsIgnoreCase(cPass)){
				System.out.println("password yang anda masukan tidak sama");
				menuSignUp();
			}else{
				try {
		            String sql = "INSERT INTO petcare VALUES ('"+user+"','"+noInduk+"','"+nama+"','"+pass+"')";
		            Connection conn=(Connection)config.configDB();
		            PreparedStatement pst=conn.prepareStatement(sql);
		            pst.execute();
		            System.out.println();
		            System.out.println("data berhasil di simpan");
		            menuLogin();
		        } catch (Exception e) {
		            System.out.println("\nusername tidak boleh sama!!!!");
		            menuSignUp();
		        }
			}	
		}else {
			System.out.println();
			System.out.println("invalid field");
			menuSignUp();
		}
		
		
	}
}