import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

public class MenuUtama {
	
	public static String pilihan, pemilik, kucing, jenisK, alamat, umur, noTelp;
	public static Scanner masukan = new Scanner(System.in);
	
public static void menuUtama(String namaUser) {
	System.out.println("*********** Selamat datang di menu utama "+namaUser+" ***********");
	System.out.println("Pilih menu");
	System.out.println("Pengadopsi");
	System.out.println("Pemilik kucing");
	System.out.println("Log Out");
	System.out.print("Choose your choice: ");
	pilihan = masukan.nextLine();
	if(pilihan.equalsIgnoreCase("pengadopsi")) {
			menuPengadopsi(namaUser);
		}else if(pilihan.equalsIgnoreCase("pemilik kucing")) {
			menuPemilik(namaUser);
		}else if(pilihan.equalsIgnoreCase("Log Out")){
			System.out.println("Log Out telah berhasil");
			PetCare.main(null);
		}else {
			System.out.println("tidak ada pilihan yang tepat");
			menuUtama(namaUser);
		}
	}

public static void menuPengadopsi(String namaUser) {
	System.out.println("############ Selamat datang untuk pengadopsi kucing ######################");
	try {
		System.out.println("Kucing yang tersedia\n");
        String sql = "select * from pemilik";
        Connection conn=(Connection)config.configDB();
        Statement stm=conn.createStatement();
        ResultSet res=stm.executeQuery(sql);
        while(res.next()) {
        	System.out.println("Kode Kucing: " + res.getString("kode"));
        	System.out.println("Nama Kucing: " + res.getString("nama_kucing"));
        	System.out.println("Jenis Kucing: " + res.getString("jenis_kucing"));
        	System.out.println("Umur Kucing: " + res.getString("umur"));
        	System.out.println();
        }
        System.out.print("Pilih kode kucing: ");
        String kode = masukan.next();
        System.out.println("Anda akan dialihkan ke payment");
        Payment.pembayaran(kode, namaUser);
    } catch (Exception e) {
    	}
	}

public static void menuPemilik(String namaUser) {
	Random random = new Random();
	String angka = "";
	System.out.println("############ Selamat datang untuk pemilik kucing ######################");
	System.out.println("Silahkan isi data dibawah untuk kucing yang ingin diadopsi");
	System.out.print("Nama Pemilik: ");
	pemilik = masukan.nextLine();
	System.out.print("Nama Kucing: ");
	kucing = masukan.nextLine();
	System.out.print("Jenis Kucing: ");
	jenisK = masukan.nextLine();
	System.out.print("Umur Kucing: ");
	umur = masukan.nextLine();
	System.out.print("No Telp: ");
	noTelp = masukan.nextLine();
	System.out.print("Alamat: ");
	alamat = masukan.nextLine();
	
	for(int i = 0; i < 3; i++) {
		int randomValue = random.nextInt(10);
		angka += randomValue+"";
	}
	if(pemilik.isEmpty() || kucing.isEmpty() || jenisK.isEmpty() || umur.isEmpty() || noTelp.isEmpty() || alamat.isEmpty()) {
		System.out.println("data yang anda masukan tidak valid");
		menuPemilik(namaUser);
	}else {
		try {
	        String sql = "INSERT INTO pemilik VALUES ('"+angka+"','"+pemilik+"','"+kucing+"','"+jenisK+"','"
	        											+umur+"','"+noTelp+"','"+alamat+"')";
	        Connection conn=(Connection)config.configDB();
	        PreparedStatement pst=conn.prepareStatement(sql);
	        pst.execute();
	        System.out.println("data berhasil di simpan");
	        menuUtama(namaUser);
	    } catch (Exception e) {
	        System.out.println("ada kesalahan pengisian data");
	        menuPemilik(namaUser);
	    }	
	}
	
	
	}
}
