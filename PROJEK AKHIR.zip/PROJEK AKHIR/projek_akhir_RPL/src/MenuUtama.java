import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

public class MenuUtama {
	
	public static String pilihan, pemilik, kucing, jenisK, alamat, umur, noTelp, kode;
    public static Connection conn1, conn2;
    public static Statement stm1;
    public static ResultSet res1;
	public static Scanner masukan = new Scanner(System.in);
	
public static void menuUtama(String namaUser) {
	Scanner masukan1 = new Scanner(System.in);
	System.out.println("*********** Selamat datang di menu utama "+namaUser+" ***********");
	System.out.println("Pilih menu");
	System.out.println("Pengadopsi");
	System.out.println("Pemilik kucing");
	System.out.println("Log Out");
	System.out.print("Choose your choice: ");
	pilihan = masukan1.nextLine();
	if(pilihan.equalsIgnoreCase("pengadopsi")) {
			menuPengadopsi(namaUser);
		}else if(pilihan.equalsIgnoreCase("pemilik kucing")) {
			menuPemilik(namaUser);
		}else if(pilihan.equalsIgnoreCase("Log Out")){
			System.out.println("\nLog Out telah berhasil\n");
			PetCare.main(null);
		}else {
			System.out.println("tidak ada pilihan yang tepat");
			menuUtama(namaUser);
		}
	}

public static void menuPengadopsi(String namaUser) {
	System.out.println("\n############ Selamat datang untuk pengadopsi kucing ######################");
	try {
		boolean flag = true;
		System.out.println("Kucing yang tersedia\n");
        String sql = "select * from pemilik";
        Connection conn=(Connection)config.configDB();
        Statement stm=conn.createStatement();
        ResultSet res=stm.executeQuery(sql);
        //ResultSet res4=stm.executeQuery(sql);
        	while(res.next()) {
        		flag = false;
        		System.out.println("Kode Kucing: " + res.getString("kode"));
            	System.out.println("Nama Kucing: " + res.getString("nama_kucing"));
            	System.out.println("Jenis Kucing: " + res.getString("jenis_kucing"));
            	System.out.println("Umur Kucing: " + res.getString("umur"));
            	System.out.println();	
        }	
        		
        if(flag) {
        	
        		System.out.println("Kucing untuk diadopsi sedang tidak tersedia");
        		System.out.println();
        		menuUtama(namaUser);
        }
        
        System.out.print("Pilih kode kucing: ");
        kode = masukan.next();
        if(kode.matches("[\\d]*")) {
        	String sql1 = "select * from pemilik where kode = '"+kode+"'";
        	conn1 =(Connection)config.configDB();
        	stm1 =conn1.createStatement();
        	res1 =stm1.executeQuery(sql1);
        	while(res1.next()) {
            	if(res1.getString("kode").equals(kode)) {
            		System.out.println();
            		System.out.println("Dengan ini saya menyatakan bahwa saya akan menjaga\nhewan tersebut dan tidak akan menyakitinya");
            		System.out.print("Y/N ");
                    String persetujuan = masukan.next();
                    if(persetujuan.equalsIgnoreCase("Y")) {
                    	
                    	String sql2 = "DELETE FROM pemilik WHERE kode = '"+kode+"'";
                    	conn2 =(Connection)config.configDB();
                    	PreparedStatement st=conn2.prepareStatement(sql2);
                    	st.executeUpdate();
                        	System.out.println("\nAnda akan dialihkan ke payment");
                        	System.out.println();
                            Payment.pembayaran(kode, namaUser);	
                    }else {
                    	System.out.println("\nMaaf anda tidak bisa melanjutkan");
                    	System.out.println();
                    	menuPengadopsi(namaUser);
                    }
            			
            	}else {
            		System.out.println();
            		System.out.println("Kode yang anda masukan salah");
            		System.out.println();
            		menuPengadopsi(namaUser);
            	}
            		
            }	
        }else {
        	System.out.println();
        	System.out.println("Kode berupa angka bukan huruf!");
        	System.out.println();
        	menuPengadopsi(namaUser);
        }
        
        System.out.println();
    	System.out.println("Kode yang anda masukan salah");
    	System.out.println();
    	menuPengadopsi(namaUser);
    	
    } catch (Exception e) {
//    	System.out.println();
//		System.out.println("Kode yang anda masukan salah");
//		System.out.println();
//		menuPengadopsi(namaUser);
    	}
	}

public static void menuPemilik(String namaUser) {
	Random random = new Random();
	String angka = "";
	Scanner input = new Scanner(System.in);
	System.out.println("\n############ Selamat datang untuk pemilik kucing ######################");
	System.out.println("Silahkan isi data dibawah untuk kucing yang ingin diadopsi");
	System.out.print("Nama Pemilik: ");
	pemilik = input.nextLine();
	System.out.print("Nama Kucing: ");
	kucing = input.nextLine();
	System.out.print("Jenis Kucing: ");
	jenisK = input.nextLine();
	System.out.print("Umur Kucing: ");
	umur = input.nextLine();
	System.out.print("No Telp: ");
	noTelp = input.nextLine();
	System.out.print("Alamat: ");
	alamat = input.nextLine();
	
	for(int i = 0; i < 3; i++) {
		int randomValue = random.nextInt(10);
		angka += randomValue+"";
	}
	
	if(pemilik.isEmpty() || kucing.isEmpty() || jenisK.isEmpty() || umur.isEmpty() || noTelp.isEmpty() || alamat.isEmpty()) {
		System.out.println("data yang anda masukan tidak valid");
		menuPemilik(namaUser);
	}else {
		if(pemilik.matches("[a-zA-Z]*") && kucing.matches("[a-zA-Z]*") && jenisK.matches("[a-zA-Z]*") && noTelp.matches("[\\d]*") && umur.matches("[\\d]*")) {
			try {
		        String sql = "INSERT INTO pemilik VALUES ('"+angka+"','"+pemilik+"','"+kucing+"','"+jenisK+"','"
		        											+umur+"','"+noTelp+"','"+alamat+"')";
		        Connection conn=(Connection)config.configDB();
		        PreparedStatement pst=conn.prepareStatement(sql);
		        pst.execute();
		        System.out.println("data berhasil di simpan");
		        menuUtama(namaUser);
		    } catch (Exception e) {
		        System.out.println("ada kesalahan pengisian data");
		        menuPemilik(namaUser);
		    }	
		}else {
			System.out.println("Inputan tidak sesuai");
			menuPemilik(namaUser);
		}
			
	}
	
	
	}
}
